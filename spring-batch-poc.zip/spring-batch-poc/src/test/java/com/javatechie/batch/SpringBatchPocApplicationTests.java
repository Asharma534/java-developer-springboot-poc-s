package com.javatechie.batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchPocApplicationTests {

	@Test
	void contextLoads() {
	}

}
