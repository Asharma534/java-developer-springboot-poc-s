package com.javatechie.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBatchPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBatchPocApplication.class, args);
	}

}
